function fix_window() {
  window.focus();
}
